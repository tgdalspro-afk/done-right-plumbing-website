# Done Right Plumbing — Website

Production-ready website for Done Right Plumbing, Thousand Oaks CA.

## Files

```
done-right-plumbing/
├── index.html      — Full page structure, semantic HTML
├── styles.css      — All styles, mobile-first, responsive
├── script.js       — Animations, FAQ, sticky nav, mobile bar
└── README.md       — This file
```

---

## Deploy to Netlify (3 steps)

### Option A — Drag & Drop (fastest, no account setup needed)

1. Go to **https://app.netlify.com/drop**
2. Drag the entire `done-right-plumbing` folder onto the page
3. Done — Netlify gives you a live URL instantly

### Option B — Netlify CLI

```bash
# Install Netlify CLI (one time)
npm install -g netlify-cli

# From inside the project folder
cd done-right-plumbing
netlify deploy --prod --dir .
```

### Option C — GitHub + Netlify (recommended for ongoing updates)

1. Push the folder to a GitHub repo
2. Log in to Netlify → **Add new site** → **Import from Git**
3. Select your repo — leave all build settings blank (no build command needed)
4. Set **Publish directory** to `/` (or leave blank)
5. Click **Deploy site**

---

## Custom Domain (after deploying)

1. In Netlify dashboard → **Domain settings** → **Add custom domain**
2. Enter your domain (e.g. `doneriteplumbing.com`)
3. Update your domain's DNS nameservers to Netlify's (shown in the dashboard)
4. Netlify auto-provisions SSL/HTTPS — no extra steps needed

---

## Analytics (optional)

To track phone call clicks, uncomment the Google Analytics event in `script.js`:

```js
// In initPhoneTracking(), replace the comment with:
gtag('event', 'phone_call_click', {
  event_category: 'CTA',
  event_label: 'done_right_plumbing'
});
```

Then add your Google Analytics tag to the `<head>` in `index.html`.

---

## Performance Notes

- No build tools required — pure HTML/CSS/JS
- Fonts loaded from Google Fonts with `preconnect` for speed
- All animations use `IntersectionObserver` — zero layout thrash
- `prefers-reduced-motion` respected for accessibility
- Images: none required (design is type and color-based)
- Mobile sticky call bar appears after scrolling past the hero

---

## Contact Info in the Site

All contact details are hardcoded. To update:

| Detail | File | Search for |
|---|---|---|
| Phone number | `index.html` | `8055518565` |
| Address | `index.html` | `3948 Elkwood St` |
| Hours | `index.html` | `8am – 5pm` |
| Rating | `index.html` | `4.8` |
| Review count | `index.html` | `27+` |

---

Built for Done Right Plumbing — Thousand Oaks, CA
